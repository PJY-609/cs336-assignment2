import json
import platform
import torch
import triton
from triton.testing import do_bench
from cs336_systems.flashattention import FlashAttentionTriton, NaiveAttention

assert torch.cuda.is_available()
assert torch.cuda.device_count() == 1
assert torch.cuda.is_bf16_supported()
print(json.dumps(dict(python=platform.python_version(), torch=torch.__version__, triton=triton.__version__, cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(0), capability=torch.cuda.get_device_capability(0), memory_gib=torch.cuda.get_device_properties(0).total_memory / 2**30)), flush=True)
torch.manual_seed(0)
for dtype in (torch.float32, torch.bfloat16):
    q, k, v = [torch.randn(1, 128, 64, device='cuda', dtype=dtype, requires_grad=True) for _ in range(3)]
    do = torch.randn_like(q)
    scores = q @ k.transpose(-2, -1) / 8
    mask = torch.ones(128, 128, device='cuda', dtype=torch.bool).triu(1)
    reference = scores.masked_fill(mask, float('-inf')).softmax(-1) @ v
    ref_grads = torch.autograd.grad(reference, (q, k, v), do)
    for impl in (FlashAttentionTriton, NaiveAttention):
        out = impl.apply(q, k, v, True)
        grads = torch.autograd.grad(out, (q, k, v), do)
        torch.cuda.synchronize()
        assert torch.isfinite(out).all()
        for grad in grads:
            assert torch.isfinite(grad).all()
        torch.testing.assert_close(out, reference, atol=0.03, rtol=0.03)
        for grad, ref in zip(grads, ref_grads):
            torch.testing.assert_close(grad, ref, atol=0.05, rtol=0.05)
        ms = do_bench(lambda: impl.apply(q, k, v, True), warmup=10, rep=30)
        print(f'{dtype} {impl.__name__}: forward/backward smoke passed; do_bench returned {ms:.4f} ms (smoke timing only)', flush=True)
print('PASS', flush=True)
