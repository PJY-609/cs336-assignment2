# Attention benchmark on a single H200

Batch size 1; causal masking; median CUDA-event latency in milliseconds.
Naive = existing compiled dense PyTorch; Flash PyTorch = eager tiled Python loops.
Tile tuning, correctness checks, input generation and compilation are outside timing.
Partial results are saved after each case. Blank cells are not measured values.

| Implementation | N | D | Dtype | Q tile | K tile | Forward ms | Backward ms | Fwd+bwd ms | Status |
|---|---:|---:|---|---:|---:|---:|---:|---:|---|
| naive | 128 | 64 | bfloat16 |  |  | 0.0687 | 0.2134 | 0.4128 | ok |
| flash_pytorch | 128 | 64 | bfloat16 | 128 | 128 | 0.2042 | 0.4689 | 0.7913 | ok |
| flash_triton | 128 | 64 | bfloat16 | 64 | 32 | 0.0081 | 0.1074 | 0.1782 | ok |
| naive | 128 | 64 | float32 |  |  | 0.0573 | 0.2149 | 0.3915 | ok |
| flash_pytorch | 128 | 64 | float32 | 128 | 128 | 0.2953 | 0.4066 | 0.8246 | ok |
| flash_triton | 128 | 64 | float32 | 16 | 16 | 0.0188 | 0.1412 | 0.2719 | ok |
