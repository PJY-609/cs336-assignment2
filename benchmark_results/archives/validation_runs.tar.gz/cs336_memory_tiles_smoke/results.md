# Attention benchmark on a single H200

Batch size 1; causal masking; median CUDA-event latency in milliseconds.
Naive = existing compiled dense PyTorch; Flash PyTorch = eager tiled Python loops.
Tile tuning, correctness checks, input generation and compilation are outside timing.
Peak memory is total PyTorch-allocated GPU memory in decimal GB, including preallocated inputs.
Forward and forward+backward memory are measured in separate untimed passes.
Partial results are saved after each case. Blank cells are not measured values.

| Implementation | N | D | Dtype | Q tile | K tile | Forward ms | Backward ms | Fwd+bwd ms | Forward peak GB | Fwd+bwd peak GB | Status |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| naive | 128 | 64 | bfloat16 |  |  | 0.0706 | 0.1855 | 0.3755 | 0.0672 | 0.0673 | ok |
| flash_pytorch | 128 | 64 | bfloat16 | 128 | 128 | 0.2017 | 0.5087 | 0.9129 | 0.0673 | 0.0675 | ok |
| flash_triton | 128 | 64 | bfloat16 | 64 | 32 | 0.0161 | 0.0987 | 0.1987 | 0.0672 | 0.0673 | ok |
