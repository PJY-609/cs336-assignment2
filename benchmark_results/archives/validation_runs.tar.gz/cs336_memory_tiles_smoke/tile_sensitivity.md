# Triton tile-size sensitivity on a single H200

Batch size 1; causal masking; median CUDA-event latency in milliseconds.
Naive = existing compiled dense PyTorch; Flash PyTorch = eager tiled Python loops.
Tile tuning, correctness checks, input generation and compilation are outside timing.
Peak memory is total PyTorch-allocated GPU memory in decimal GB, including preallocated inputs.
Forward and forward+backward memory are measured in separate untimed passes.
Partial results are saved after each case. Blank cells are not measured values.

| Implementation | N | D | Dtype | Q tile | K tile | Forward ms | Backward ms | Fwd+bwd ms | Forward peak GB | Fwd+bwd peak GB | Status |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| flash_triton | 128 | 64 | bfloat16 | 32 | 32 | 0.0173 | 0.1105 | 0.2019 | 0.0672 | 0.0673 | ok |
| flash_triton | 128 | 64 | bfloat16 | 32 | 128 | 0.0191 | 0.1659 | 0.2838 | 0.0672 | 0.0673 | ok |
| flash_triton | 128 | 64 | bfloat16 | 128 | 32 | 0.0151 | 0.1210 | 0.2016 | 0.0672 | 0.0673 | ok |
| flash_triton | 128 | 64 | bfloat16 | 128 | 128 | 0.0134 | 0.1189 | 0.1963 | 0.0672 | 0.0673 | ok |
