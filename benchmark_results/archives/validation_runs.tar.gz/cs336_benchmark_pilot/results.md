# Attention benchmark on a single H200

Batch size 1; causal masking; median CUDA-event latency in milliseconds.
Naive = existing compiled dense PyTorch; Flash PyTorch = eager tiled Python loops.
Tile tuning, correctness checks, input generation and compilation are outside timing.
Partial results are saved after each case. Blank cells are not measured values.

| Implementation | N | D | Dtype | Q tile | K tile | Forward ms | Backward ms | Fwd+bwd ms | Status |
|---|---:|---:|---|---:|---:|---:|---:|---:|---|
| flash_pytorch | 4096 | 128 | float32 | 1024 | 1024 | 3.0296 | 6.2778 | 11.0420 | ok |
| flash_triton | 4096 | 128 | float32 | 16 | 16 | 1.4025 | 5.5026 | 6.9017 | ok |
