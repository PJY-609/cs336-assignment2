# Attention benchmark on a single H200

Batch size 1; causal masking; median CUDA-event latency in milliseconds.
Naive = existing compiled dense PyTorch; Flash PyTorch = eager tiled Python loops.
Tile tuning, correctness checks, input generation and compilation are outside timing.
Partial results are saved after each case. Blank cells are not measured values.

| Implementation | N | D | Dtype | Q tile | K tile | Forward ms | Backward ms | Fwd+bwd ms | Status |
|---|---:|---:|---|---:|---:|---:|---:|---:|---|
| naive | 128 | 16 | bfloat16 |  |  | 0.0542 | 0.1506 | 0.3243 | ok |
| flash_pytorch | 128 | 16 | bfloat16 | 128 | 128 | 0.3117 | 0.4473 | 0.9388 | ok |
| flash_triton | 128 | 16 | bfloat16 | 64 | 32 | 0.0131 | 0.1114 | 0.2003 | ok |
| naive | 128 | 16 | float32 |  |  | 0.0570 | 0.1858 | 0.3187 | ok |
| flash_pytorch | 128 | 16 | float32 | 128 | 128 | 0.2946 | 0.4961 | 0.9374 | ok |
| flash_triton | 128 | 16 | float32 | 64 | 64 | 0.0158 | 0.1012 | 0.1748 | ok |
| naive | 128 | 32 | bfloat16 |  |  | 0.0584 | 0.2097 | 0.3908 | ok |
| flash_pytorch | 128 | 32 | bfloat16 | 128 | 128 | 0.1984 | 0.4644 | 0.8840 | ok |
| flash_triton | 128 | 32 | bfloat16 | 64 | 64 | 0.0072 | 0.1048 | 0.2026 | ok |
| naive | 128 | 32 | float32 |  |  | 0.0275 | 0.2044 | 0.3555 | ok |
| flash_pytorch | 128 | 32 | float32 | 128 | 128 | 0.2892 | 0.5160 | 0.9486 | ok |
| flash_triton | 128 | 32 | float32 | 16 | 16 | 0.0131 | 0.0932 | 0.1844 | ok |
| naive | 128 | 64 | bfloat16 |  |  | 0.0589 | 0.2028 | 0.3885 | ok |
| flash_pytorch | 128 | 64 | bfloat16 | 128 | 128 | 0.2903 | 0.4958 | 0.9884 | ok |
| flash_triton | 128 | 64 | bfloat16 | 64 | 32 | 0.0189 | 0.1176 | 0.2072 | ok |
| naive | 128 | 64 | float32 |  |  | 0.0605 | 0.2058 | 0.4008 | ok |
| flash_pytorch | 128 | 64 | float32 | 128 | 128 | 0.2690 | 0.4711 | 0.9435 | ok |
| flash_triton | 128 | 64 | float32 | 32 | 32 | 0.0194 | 0.0962 | 0.1872 | ok |
| naive | 128 | 128 | bfloat16 |  |  | 0.0245 | 0.1459 | 0.2579 | ok |
| flash_pytorch | 128 | 128 | bfloat16 | 128 | 128 | 0.1983 | 0.4682 | 0.7818 | ok |
| flash_triton | 128 | 128 | bfloat16 | 64 | 64 | 0.0156 | 0.1160 | 0.2080 | ok |
| naive | 128 | 128 | float32 |  |  | 0.0628 | 0.1594 | 0.3192 | ok |
| flash_pytorch | 128 | 128 | float32 | 128 | 128 | 0.2970 | 0.5020 | 1.0359 | ok |
| flash_triton | 128 | 128 | float32 | 16 | 16 | 0.0292 | 0.1064 | 0.1906 | ok |
| naive | 256 | 16 | bfloat16 |  |  | 0.0740 | 0.2329 | 0.4584 | ok |
| flash_pytorch | 256 | 16 | bfloat16 | 256 | 256 | 0.1972 | 0.5111 | 0.7807 | ok |
| flash_triton | 256 | 16 | bfloat16 | 64 | 64 | 0.0158 | 0.1213 | 0.2401 | ok |
| naive | 256 | 16 | float32 |  |  | 0.0762 | 0.2033 | 0.3812 | ok |
| flash_pytorch | 256 | 16 | float32 | 256 | 256 | 0.3078 | 0.5137 | 1.0685 | ok |
| flash_triton | 256 | 16 | float32 | 64 | 64 | 0.0176 | 0.0956 | 0.1840 | ok |
| naive | 256 | 32 | bfloat16 |  |  | 0.0736 | 0.1874 | 0.3838 | ok |
| flash_pytorch | 256 | 32 | bfloat16 | 256 | 256 | 0.2037 | 0.4652 | 0.7826 | ok |
| flash_triton | 256 | 32 | bfloat16 | 64 | 64 | 0.0081 | 0.1303 | 0.1922 | ok |
| naive | 256 | 32 | float32 |  |  | 0.0767 | 0.2049 | 0.3846 | ok |
| flash_pytorch | 256 | 32 | float32 | 256 | 256 | 0.2065 | 0.4843 | 0.8132 | ok |
| flash_triton | 256 | 32 | float32 | 32 | 32 | 0.0215 | 0.0938 | 0.1834 | ok |
| naive | 256 | 64 | bfloat16 |  |  | 0.0848 | 0.1845 | 0.3943 | ok |
| flash_pytorch | 256 | 64 | bfloat16 | 256 | 256 | 0.2882 | 0.3804 | 0.8619 | ok |
| flash_triton | 256 | 64 | bfloat16 | 32 | 32 | 0.0113 | 0.1011 | 0.1685 | ok |
| naive | 256 | 64 | float32 |  |  | 0.0741 | 0.1984 | 0.4683 | ok |
| flash_pytorch | 256 | 64 | float32 | 256 | 256 | 0.2074 | 0.5719 | 1.0260 | ok |
| flash_triton | 256 | 64 | float32 | 32 | 32 | 0.0554 | 0.1257 | 0.1896 | ok |
| naive | 256 | 128 | bfloat16 |  |  | 0.0717 | 0.1864 | 0.3833 | ok |
| flash_pytorch | 256 | 128 | bfloat16 | 256 | 256 | 0.2184 | 0.3586 | 0.7104 | ok |
| flash_triton | 256 | 128 | bfloat16 | 32 | 32 | 0.0199 | 0.1513 | 0.2754 | ok |
| naive | 256 | 128 | float32 |  |  | 0.0775 | 0.1351 | 0.2717 | ok |
| flash_pytorch | 256 | 128 | float32 | 256 | 256 | 0.2125 | 0.5275 | 0.9381 | ok |
| flash_triton | 256 | 128 | float32 | 16 | 16 | 0.0522 | 0.1988 | 0.2487 | ok |
| naive | 512 | 16 | bfloat16 |  |  | 0.0696 | 0.1831 | 0.3442 | ok |
| flash_pytorch | 512 | 16 | bfloat16 | 512 | 512 | 0.2071 | 0.4726 | 0.8178 | ok |
| flash_triton | 512 | 16 | bfloat16 | 32 | 32 | 0.0116 | 0.1079 | 0.1775 | ok |
| naive | 512 | 16 | float32 |  |  | 0.0707 | 0.1396 | 0.3085 | ok |
| flash_pytorch | 512 | 16 | float32 | 512 | 512 | 0.2093 | 0.4729 | 0.8126 | ok |
| flash_triton | 512 | 16 | float32 | 32 | 32 | 0.0244 | 0.0891 | 0.1857 | ok |
| naive | 512 | 32 | bfloat16 |  |  | 0.0756 | 0.2298 | 0.4293 | ok |
| flash_pytorch | 512 | 32 | bfloat16 | 512 | 512 | 0.2763 | 0.5215 | 1.2109 | ok |
| flash_triton | 512 | 32 | bfloat16 | 32 | 32 | 0.0165 | 0.1201 | 0.1887 | ok |
| naive | 512 | 32 | float32 |  |  | 0.0777 | 0.1997 | 0.4079 | ok |
| flash_pytorch | 512 | 32 | float32 | 512 | 512 | 0.2177 | 0.5083 | 1.1277 | ok |
| flash_triton | 512 | 32 | float32 | 16 | 16 | 0.0364 | 0.1109 | 0.1626 | ok |
| naive | 512 | 64 | bfloat16 |  |  | 0.0692 | 0.1999 | 0.3547 | ok |
| flash_pytorch | 512 | 64 | bfloat16 | 512 | 512 | 0.2215 | 0.5046 | 0.9598 | ok |
| flash_triton | 512 | 64 | bfloat16 | 64 | 32 | 0.0150 | 0.1083 | 0.1956 | ok |
| naive | 512 | 64 | float32 |  |  | 0.0708 | 0.2307 | 0.3817 | ok |
| flash_pytorch | 512 | 64 | float32 | 512 | 512 | 0.2076 | 0.4796 | 0.8786 | ok |
| flash_triton | 512 | 64 | float32 | 16 | 16 | 0.0572 | 0.1888 | 0.2593 | ok |
| naive | 512 | 128 | bfloat16 |  |  | 0.0383 | 0.1451 | 0.3087 | ok |
