# Batch-size sweep

Causal attention; fixed baseline tiles; all batch-size-1 timings rerun.

| batch_size | sequence_length | embedding_dim | dtype | implementation | q_tile | k_tile | forward_ms | backward_ms | forward_backward_ms | tokens_per_second | forward_peak_gb | forward_backward_peak_gb | status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | 128 | 64 | float32 | naive |  |  | 0.03728 | 0.263552 | 0.708352 | 361402 | 0.0676342 | 0.0678318 | ok |
| 2 | 128 | 64 | float32 | flash_pytorch | 128 | 128 | 0.25824 | 1.42534 | 2.92325 | 87573.8 | 0.0679844 | 0.0687514 | ok |
| 2 | 128 | 64 | float32 | flash_triton | 32 | 32 | 0.020704 | 0.380512 | 0.62704 | 408267 | 0.0674376 | 0.0676352 | ok |
